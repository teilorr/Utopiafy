from __future__ import annotations
from typing import (
    TYPE_CHECKING,
)

from discord.ext import commands
import discord

from utils import (
    convertToSeconds,
    Configs,
    WarningsDatabase
)

import datetime as dt
from components.menus.show_warns import MySource, WarnsMenuPages
import re

if TYPE_CHECKING:
    from core import Utopify

class Moderation(commands.Cog):
    def __init__(self, bot: Utopify) -> None:
        self.bot = bot

    @commands.command(name="ban", help="Bane um mebro", hidden=True)
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx: commands.Context, member: discord.Member, *, reason: str=None) -> None:
        await member.ban(reason=reason or "Motivo não informado")

        await self.bot.logs_channel.send(embed=
            discord.Embed(
                description=
                    f"***\U00002702 Banido***: {member} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author} *({ctx.author.id})*\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'}"
                ,
                color=discord.Color.red()
            )
            .set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")
            .set_author(name=f"{member.name} foi banido por {ctx.author.name}")
        )

    @commands.command(name="unban", help="Desbane um mebro", hidden=True)
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx: commands.Context, member: discord.Member, *, reason: str=None) -> None:
        await member.unban(reason=reason or "Motivo não informado")

        await self.bot.logs_channel.send(embed=
            discord.Embed(
                description=
                    f"***\U00002702 Desbanido***: {member} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author} *({ctx.author.id})*\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'}"
                ,
                color=discord.Color.brand_green()
            )
            .set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")
            .set_author(name=f"{member.name} foi debanido por {ctx.author.name}")
        )

    @commands.command(name="kick", help="Expula um mebro", hidden=True)
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx: commands.Context, member: discord.Member, *, reason: str=None) -> None:
        await member.kick(reason=reason or "Motivo não informado")

        await self.bot.logs_channel.send(embed=
            discord.Embed(
                description=
                    f"***\U00002702 Expulso***: {member} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author} *({ctx.author.id})*\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'}"
                ,
                color=discord.Color.red()
            )
            .set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")
            .set_author(name=f"{member.name} foi expulso por {ctx.author.name}")
        )

    @commands.command(name="mute", help="Silencia um usuário", hidden=True)
    @commands.has_permissions(manage_messages=True)
    async def mute(self, ctx: commands.Context, member: discord.Member, time: str, *, reason: str=None) -> None:
        on_seconds = await convertToSeconds().convert(ctx, time)

        if member.is_timed_out():
            return await ctx.send(f"> O Membro *{member}* já está silenciado")

        await member.timeout(dt.timedelta(seconds=on_seconds))
        await ctx.send(f"> Silenciei *{member}* por *{time}* com sucesso! :tada:")

        await self.bot.logs_channel.send(embed=
            discord.Embed(
                description=
                    f"***\U0001f507 Silenciado***: {member.mention} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author} *({ctx.author.id})*\n"
                    f"***\U000023f0 Tempo***: {time}\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'}"
                ,
                color=discord.Color.red()
            )
            .set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")
            .set_author(name=f"{member.name} foi silenciado por {ctx.author.name}")
        )

    @commands.command(name="unmute", help="Desmuta um usuário", hidden=True)
    @commands.has_permissions(manage_messages=True)
    async def unmute(self, ctx: commands.Context, member: discord.Member, *, reason: str=None) -> None:
        
        if not member.is_timed_out():
            return await ctx.send(f"> O Membro *{member}* não está silenciado!")

        await member.timeout(None)
        await ctx.send(f"> Desmutei *{member}* com sucesso! :tada:")
        
        async for msg in self.bot.logs_channel.history(limit=5):
            matches = (int(m) for m in re.findall(r"[0-9]+", msg.embeds[0].description))
            if member.id in matches:
                await msg.delete()
                return

        await self.bot.logs_channel.send(embed=
            discord.Embed(
                description=
                    f"***\U0001f507 Desmutado***: {member} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author} *({ctx.author.id})*\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'}"
                ,
                color=discord.Color.brand_green()
            )
            .set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")
            .set_author(name=f"{member.name} foi desmutado por {ctx.author.name}")
        )

    @commands.command(name="report", help="Reporta um usuário")
    async def report(self, ctx: commands.Context, member: discord.Member, *, reason: str) -> None:
        await ctx.message.delete()

        report_channel = ctx.guild.get_channel(Configs.report_channel_id)
        embed = discord.Embed(
            description=
                f"***\U0001f50e Reportado***: {member.mention} *({member.id})*\n"
                f"***\U0001f4dc Motivo***: {reason} | [Ver mensagem]({ctx.message.jump_url})\n"
                f"***\U00000023 Canal***: {ctx.channel.mention}\n"
            ,
            color=0x00000 # preto
        )
        embed.set_author(name=f"Autor do report: {ctx.author.name} ({ctx.author.id})")
        embed.timestamp = dt.datetime.now()

        await ctx.send(f"> *{member}* foi reportado com sucesso")
        logs_msg = await report_channel.send(embed=embed)
        
        await logs_msg.add_reaction("\U0001f7e9") # quadrado verde
        await logs_msg.add_reaction("\U0001f7e7") # quadrado laranja
        await logs_msg.add_reaction("\U0001f7e5") # quadrado vermelho
        await logs_msg.add_reaction("\U00002b1c") # quadrado branco
        await logs_msg.add_reaction("\U0001f5d1") # lixeira

    @commands.command(name="warn", hidden=True)
    @commands.has_permissions(manage_messages=True)
    async def warn(self, ctx: commands.Context, member: discord.Member, *, reason: str) -> None:
        async with WarningsDatabase() as db:
            warn = await db.warn(member, reason, ctx.author)
            embed = discord.Embed(
                description=
                    f"***\U0001f507 Avisado***: {member.mention} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {ctx.author.mention} *({ctx.author.id})*\n"
                    f"***\U0001f4dc Motivo***: {reason or 'Nenhum motivo informado'} | [Ver mensagem]({ctx.message.jump_url})\n"
                    f"***\U0001f522 ID Do warn***: {warn.warn_id}"
                ,
                color=discord.Color.orange()
            )
            embed.set_author(name=f"{member.name} foi avisado por {ctx.author.name}")
            embed.set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")

            await self.bot.logs_channel.send(embed=embed)
            await ctx.send(embed=embed)

    @commands.command(name="warnings", hidden=True)
    async def warns(self, ctx: commands.Context, member: discord.Member) -> None:
        async with WarningsDatabase() as db:
            warns = await db.get_warns_from(member)

        if warns is None:
            return await ctx.send(f"> *{member}* não tem nenhum warn!")

        async with ctx.typing():
            formatter = MySource(warns, self.bot, ctx, per_page=6)
            menu = WarnsMenuPages(formatter)
            await menu.start(ctx)

    @commands.command(name="remove_warn", aliases=["warn_remove"], hidden=True)
    @commands.has_permissions(manage_channels=True)
    async def remove_warn(self, ctx: commands.Context, warn_id: int) -> None:
        async with WarningsDatabase() as db:
            if (removed_warn := await db.delete_warn(warn_id, ctx.guild)) is None:
                return await ctx.send("> Warn não encontrado")

            member = await self.bot.fetch_user(removed_warn.user_id)
            who_warned = await self.bot.fetch_user(removed_warn.author_id)
            
            embed = discord.Embed(
                title=f"{member} foi desavisado!",
                description=
                    f"***\U0001f507 Desavisado***: {member.mention} *({member.id})*\n"
                    f"***\U0001f451 Admin***: {who_warned.mention} *({who_warned.id})*\n"
                    f"***\U0001f4dc Motivo***: {removed_warn.reason or 'Nenhum motivo informado'}\n"
                    f"***\U0001f522 ID Do warn***: {removed_warn.warn_id}"
                ,
                color=0xff00cf
            )
            embed.set_footer(text=f"{ctx.author} • {dt.datetime.now():%d/%m/%Y}")

            await ctx.send(f"> Deletei o warn de *{member}* com sucesso", embed=embed)
            await self.bot.logs_channel.send(embed=embed)

    @commands.command(name="clear_warnings", aliases=["clear_warns"], hidden=True)
    @commands.has_permissions(manage_channels=True)
    async def clear_warns(self, ctx: commands.Context, member: discord.Member) -> None:
        async with WarningsDatabase() as db:
            await db.clear_warns_from(member, current_guild=ctx.guild)
            await ctx.send(f"> Limpei os warns de *{member}* com sucesso! :tada:")

async def setup(bot: Utopify) -> None:
    cog = Moderation(bot)
    await bot.add_cog(cog)