class Configs:
    reaction_role_message_id = 993220070652260403
    suggestion_channel_id = 794455974173474816
    report_channel_id = 794456061230841876
    errors_channel_id = 794456288306266122
    logs_channel_id = 794456444681715713
    utopia_id = 524748755208241152
    owner_id = 848662859176607764